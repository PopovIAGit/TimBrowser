﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimBrowser.DataCore.Communication
{
    public enum CommunicationError
    {
        ReceiveError = 1,
        TransmitError
    }
}
