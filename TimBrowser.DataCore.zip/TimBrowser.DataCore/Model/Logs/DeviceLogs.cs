﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TimBrowser.DataCore.Model.Logs
{
    public class DeviceLogs
    {
        public DeviceLogs(List<LogEventRecordItem> eventLog, List<LogCmdRecordItem> commandLog,
            List<LogParamRecordItem> changeParameterLog)
        {
            _eventLog = eventLog;
            _commandLog = commandLog;
            _changeParameterLog = changeParameterLog;
        }

        public DeviceLogs(List<LogEventRecordItem> eventLog, List<LogCmdRecordItem> commandLog,
            List<LogParamRecordItem> changeParameterLog, List<LogSimRecordItem> logSimRecord)
        {
            _eventLog = eventLog;
            _commandLog = commandLog;
            _changeParameterLog = changeParameterLog;
            _simLog = logSimRecord;
        }

        private List<LogEventRecordItem> _eventLog;
        private List<LogCmdRecordItem> _commandLog;
        private List<LogParamRecordItem> _changeParameterLog;
        private List<LogSimRecordItem> _simLog;

        public List<LogEventRecordItem> EventLog
        {
            get { return _eventLog; }
        }

        public List<LogCmdRecordItem> CommandLog
        {
            get { return _commandLog; }
        }

        public List<LogParamRecordItem> ChangeParameterLog
        {
            get { return _changeParameterLog; }
        }

        public List<LogSimRecordItem> SimLog
        {
            get { return _simLog; }
        }
    }
}
